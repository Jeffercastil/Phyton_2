import mysql.connector
from decouple import config

conexion = mysql.connector.connect(
    host = str(config('HOSTDB')),
    user = str(config('USERDB')),
    password = str(config('PASSDB')),
    database = str(config('DATABASE'))
)

cursor = conexion.cursor()

cursor.execute("SELECT * FROM usuarios")

usuarios = cursor.fetchall()

for usuario in usuarios:
    print("nombre:", usuario[1], "correo:", usuario[2])


cursor.execute("SELECT nombre, telefono FROM usuarios")

usuario1 = cursor.fetchone()
print(usuario1)

usuario2 = cursor.fetchone()
print(usuario2)


conexion.close()