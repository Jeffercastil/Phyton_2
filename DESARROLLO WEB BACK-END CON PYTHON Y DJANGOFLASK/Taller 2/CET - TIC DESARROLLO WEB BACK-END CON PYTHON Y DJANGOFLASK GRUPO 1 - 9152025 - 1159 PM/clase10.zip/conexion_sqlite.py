import sqlite3

conexion = sqlite3.connect("biblioteca.db")

cursor = conexion.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL,
    email TEXT UNIQUE,
    edad INTEGER
)
""")

conexion.commit()
conexion.close()