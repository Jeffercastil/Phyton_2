import sqlite3

conexion = sqlite3.connect("biblioteca.db")

cursor = conexion.cursor()

cursor.execute("""
INSERT INTO usuarios (id, nombre, email, edad)
VALUES (?, ?, ?, ?)
""", (1, "Valentina", "valentina@gmail.com", 25)
)

conexion.commit()
conexion.close()