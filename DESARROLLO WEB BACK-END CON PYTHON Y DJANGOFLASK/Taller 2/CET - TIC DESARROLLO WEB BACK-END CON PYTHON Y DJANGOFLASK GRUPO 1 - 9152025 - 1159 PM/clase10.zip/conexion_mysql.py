import mysql.connector
from decouple import config

conexion = mysql.connector.connect(
    host = str(config('HOSTDB')),
    user = str(config('USERDB')),
    password = str(config('PASSDB')),
    database = str(config('DATABASE'))
)

cursor = conexion.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS prueba (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    edad INT
)
""")

conexion.commit()
conexion.close()