import mysql.connector
from decouple import config

conexion = mysql.connector.connect(
    host = str(config('HOSTDB')),
    user = str(config('USERDB')),
    password = str(config('PASSDB')),
    database = str(config('DATABASE'))
)

cursor = conexion.cursor()

cursor.execute("""
INSERT INTO usuarios (nombre, correo, telefono)
VALUES (%s, %s, %s)
""", ("Valentina", "valentina@gmail.com", 3105485452))

usuarios = [
    ("Valeria", "valeria@gmail.com", 3105485457),
    ("Oscar", "oscar@gmail.com", 3105485458),
    ("Diego", "diego@gmail.com", 3105485459)
]


cursor.executemany("""
INSERT INTO usuarios (nombre, correo, telefono)
VALUES (%s, %s, %s)
""", usuarios)

conexion.commit()
conexion.close()